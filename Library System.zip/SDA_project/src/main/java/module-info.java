module sda_project {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    //requires mysql.connector.java;


    opens sda_project to javafx.fxml;
    exports sda_project;
}