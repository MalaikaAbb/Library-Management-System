package sda_project;

public class Review {

    private int id;
    private String studentid;
    private String rating;
    private String reviewjustification;

    public Review()
    {
        id=0;
        studentid="";
        rating="";
        reviewjustification="";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStudentid() {
        return studentid;
    }

    public String getRating() {
        return rating;
    }

    public String getReviewjustification() {
        return reviewjustification;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public void setStudentid(String studentid) {
        this.studentid = studentid;
    }

    public void setReviewjustification(String reviewjustification) {
        this.reviewjustification = reviewjustification;
    }


}
