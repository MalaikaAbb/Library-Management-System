package sda_project;

public class Course {

    private String courseCode;
    private String courseName;

    public void setCourseCode(String course) { courseCode=course; }
    public void setCourseName(String name){ courseName=name; }

    public String getCourseCode(){ return courseCode; }
    public String getCourseName(){ return courseName; }

}
