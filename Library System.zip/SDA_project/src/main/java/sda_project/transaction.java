package sda_project;

public class transaction {

    private int transactionID;
    private String studentID;
    private String operation;

    public void setTransactionID(int id){ transactionID= id; }

    public void setStudentID(String student){ studentID=student; }

    public void setOperation(String op){ operation=op; }

    public int getTransactionID(){ return transactionID; }

    public String getStudentID(){ return studentID; }

    public String getOperation(){ return operation; }
}
