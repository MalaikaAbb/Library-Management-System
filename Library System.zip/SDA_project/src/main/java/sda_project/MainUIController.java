package sda_project;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

import static java.sql.ResultSet.CONCUR_UPDATABLE;
import static java.sql.ResultSet.TYPE_SCROLL_SENSITIVE;


public class MainUIController implements Initializable{



    public Stage stage = new Stage();

    public static Student student = new Student();
    public static Librarian librarian = new Librarian();

    public static Librarian librarianloggedin = new Librarian();
    public static Student studentloggedin = new Student();

    public static transaction currentTransaction = new transaction();
    public static String rollnoverify;

    public static String reviewBook;
    public static String courseforfeedback;

    int fine=50;


    //===== STUDENT CARD VERIFICATION =====

    @FXML
    private Button VerifyButton = new Button();

    @FXML
    private TextField VerifyRollNo = new TextField();

    @FXML
    public Label VerifyFailed = new Label();


    //===== STUDENT HOME PAGE =====

    @FXML
    public Label StudentRoll = new Label();
    @FXML
    public Label StudentBatch = new Label();
    @FXML
    public Label StudentName = new Label();
    @FXML
    public Label fileComplaintLabel= new Label();
    @FXML
    public Label LogoutButton = new Label();
    @FXML
    public Label recommendCourseLabel;


    //===== LIBRARIAN HOME PAGE =====
    @FXML
    public Label LibrarianName =new Label();

    @FXML
    public Label LibrarianID = new Label();

    @FXML
    private Label BookDonationTab = new Label();

    @FXML
    private Label finePaymentLabel = new Label();

    @FXML
    private Label bookRecordsLabel = new Label();

    @FXML
    private Label manageStudentLabel;


    //===== LOGIN HOME PAGE =====

    @FXML
    private Label loginMessage;

    @FXML
    private Button loginButton;

    @FXML
    private TextField nameTextField;

    @FXML
    private TextField passwordTextField;

    //===== TITLE HOME PAGE =====

    @FXML
    private Button title_login;

    @FXML
    private Button title_register;

    @FXML
    private Button registerButton;

    //===== REGISTER PORTAL =====

    @FXML
    private TextField regUserName;

    @FXML
    private TextField regPassword;

    @FXML
    private TextField clearancePassword;
    @FXML
    private TextField regName;

    @FXML
    private Label registerMessage;

    String CLEARANCE="100497";

    //===== COMPLAINT PAGE =====

    @FXML
    private Button submitComplainButton;

    @FXML
    private CheckBox noiseCheckBox;

    @FXML
    private CheckBox materialCheckBox;

    @FXML
    private CheckBox envCheckBox;

    @FXML
    private Label complaintMessage;


    //===== RECOMMENDATION PAGE =====

    @FXML
    private Label recommendationMessage;
    @FXML
    private Label recommendHP;
    @FXML
    private TextField recommend_bookNameField;
    @FXML
    private TextField recommend_authorField;
    @FXML
    private TextField recommend_codeField;
    @FXML
    private Button recommendationSubmitButton;



    //===== FINE PAYMENT PAGE =====

    @FXML
    private Button paymentButton;
    @FXML
    private Button fineCheckButton;
    @FXML
    private TextField fineRollNumberField;
    @FXML
    private Label fineCalculationLabel;
    @FXML
    private Label fineHPReturn;

    //===== MANAGE BOOKS PAGE =====

    @FXML
    private Button addBookButton;
    @FXML
    private Button deleteBookButton;
    @FXML
    private Button updateBookButton;
    @FXML
    private Label manageBookHPLabel;
    @FXML
    private Button listBookButton;

    @FXML
    private Button viewRecsButton;

    //===== ADD BOOKS PAGE =====

    @FXML
    private TextField addBookCategoryField;
    @FXML
    private TextField addBookNameFIeld;
    @FXML
    private TextField addBookIsbnField;
    @FXML
    private Label addBookHPLabel;
    @FXML
    private Button addBookInfoButton;
    @FXML
    private Label addBookMessage;

    //===== DELETE BOOKS PAGE =====

    @FXML
    private Label deleteBookHPLabel;
    @FXML
    private Button deleteBookInfoButton;
    @FXML
    private Label deleteMessage;
    @FXML
    private TextField deleteBookIsbnField;

    //===== UPDATE BOOKS PAGE =====

    @FXML
    private Label updateBookHPLabel;
    @FXML
    private Button updateBookInfoButton;
    @FXML
    private Label updateMessage;
    @FXML
    private TextField updateBookIsbnField;
    @FXML
    private TextField updateBookCategoryField;

    //===== LIST BOOKS PAGE =====

    @FXML
    private Label listBookHPLabel;
    @FXML
    private TableColumn<Book, String> book_isbnCol;
    @FXML
    private TableColumn<Book, String> book_nameCol;
    @FXML
    private TableColumn<Book, String> book_categoryCol;
    @FXML
    private TableView<Book> book_table;

    //===== LIST STUDENTS PAGE =====
    @FXML
    private Label studentListHP;
    @FXML
    private TableColumn<Student, String> stu_rollNumCol;
    @FXML
    private TableColumn<Student, String> stu_nameCol;
    @FXML
    private TableColumn<Student, String> stu_batchCol;
    @FXML
    private TableColumn<Student, String> stu_fineCol;
    @FXML
    private TableColumn<Student, String> stu_usernameCol;
    @FXML
    private TableView<Student> student_table;


    //===== MANAGE STUDENTS PAGE =====

    @FXML
    private Button addStudentButton;
    @FXML
    private Button deleteStudentButton;
    @FXML
    private Button updateStudentButton;
    @FXML
    private Button listStudentButton;
    @FXML
    private Label manageStudentHP;



    //===== ADD STUDENTS PAGE =====

    @FXML
    private Label addStudentHP;
    @FXML
    private Label addStudentMessage = new Label();
    @FXML
    private TextField addStudentRollNumField;
    @FXML
    private TextField addStudentNameField;
    @FXML
    private TextField addStudentBatchField;
    @FXML
    private TextField addStudentUsernameField;
    @FXML
    private TextField addStudentPasswordField;
    @FXML
    private Button addStudentInfoButton;

    //===== DELETE STUDENTS PAGE =====

    @FXML
    private Label deleteStudentHP;
    @FXML
    private Label deleteStudentMessage = new Label();
    @FXML
    private TextField deleteStudentRollNumField;

    //===== UPDATE STUDENTS PAGE =====
    @FXML
    private Label updateStudentHP;
    @FXML
    private TextField updateStudentUserField;
    @FXML
    private TextField updateStudentPassField;
    @FXML
    private Button updatePasswordButton;
    @FXML
    private Label updatePasswordMessage;

    //======== RECOMMENDATION COURSE PAGE=======
    @FXML
    private Label recHomeHP;
    @FXML
    private Button recListCourseButton;
    @FXML
    private Button recCourseButton;

    //======== COURSE LIST PAGE =======

    @FXML
    private Label courseListHP;
    @FXML
    private TableColumn<Course, String> courseCodeCol;
    @FXML
    private TableColumn<Course, String> CourseNameCol;
    @FXML
    private TableView<Course> course_table;

    //======== VIEW RECOMMENDATIONS PAGE =======

    @FXML
    private TableColumn<Recommendation, String> recIDCol;
    @FXML
    private TableColumn<Recommendation, String> viewCourseCodeCol;
    @FXML
    private TableColumn<Recommendation, String> bookNameCol;
    @FXML
    private TableColumn<Recommendation, String> authorCol;
    @FXML
    private TableView<Recommendation> recommendation_table;
    @FXML
    private Label viewRecHP;


///====WAHABS PART
@FXML
private ChoiceBox<String> courseChoice = new ChoiceBox<>();
    @FXML
    private Button proceedButton = new Button();
    @FXML
    private TextField BookName = new TextField();

    @FXML
    private TextField Category = new TextField();

    @FXML
    private TextField ISBN;

    @FXML
    private TextArea feedbackText;

    @FXML
    private Button printButton;
    @FXML
    private Button submitFeedback;

    @FXML
    private Button reviewButton;

    @FXML
    public ListView<String> reviewbookList = new ListView<String>();
    @FXML
    private Label reviewBookLabel = new Label();

    @FXML
    public ListView<String> borrowList = new ListView<String>();

    @FXML
    public Label borrowTab = new Label();
    //@FXML
    //private ImageView reviewPane;

    @FXML
    private TextArea justifyRating;

    @FXML
    public ComboBox<String> q1= new ComboBox<String>();

    @FXML
    public ComboBox<String> q2= new ComboBox<String>();

    @FXML
    public ComboBox<String> q3= new ComboBox<String>();

    @FXML
    public ComboBox<String> q4= new ComboBox<String>();

    @FXML
    public ComboBox<String> q5= new ComboBox<String>();

    @FXML
    public ComboBox<String> q6= new ComboBox<String>();

    public String[] agreechoices = {"strongly disagree", "disagree", "neutral", "agree", "strongly agree"};
    public String[] goodchoices = {"very poor", "poor", "neutral", "good", "very good"};

    @FXML
    private TextField rating;

    @FXML
    private Button ratingsubmit;

    @FXML
    public Label courseName = new Label();



    //===========================
    //      COMPLAINT PAGE
    //===========================

    public void setSubmitComplainButtonOnAction(ActionEvent e) throws SQLException {
        Boolean env= envCheckBox.isSelected();
        Boolean material= materialCheckBox.isSelected();
        Boolean noise=noiseCheckBox.isSelected();

        Complaint complain = new Complaint();

        complain.setEnvComplaint(env);
        complain.setNoiseComplaint(noise);
        complain.setMaterialComplaint(material);

        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select max(ID) from proj.transaction");
        ResultSet rs=st.executeQuery(query);
        int transactionID=0;
        int complainID=0;

        if(rs.next())
        {
            transactionID=rs.getInt(1);
            transactionID += 1;
        }

        System.out.println("Student Name: " + student.getName());
        System.out.println("Student Roll No: " + student.getRollno());

        String insert=("insert into transaction(ID, Operation, studentID)" + "values ('"+ transactionID +"', 'complaint', '"+ student.getRollno() + "' )");
        st.execute(insert);



        query=("select max(complaintID) from proj.complaint");
        rs=st.executeQuery(query);

        if(rs.next())
        {
            complainID=rs.getInt(1);
            complainID += 1;
        }


        if(complain.getEnvComplaint()==true)
        {
            String complainEnv=("insert into complaint(complaintID, transactionID, StudentRollNo, Complaint)" + "values ('"+ complainID +"', '"+ transactionID +"', '"+ student.getRollno() +"', 'Unfavourable Environment')");
            st.execute(complainEnv);
        }

        if(complain.getMaterialComplaint()==true)
        {
            complainID+=1;
            String complainEnv=("insert into complaint(complaintID, transactionID, StudentRollNo, Complaint)" + "values ('"+ complainID +"', '"+ transactionID +"', '"+ student.getRollno() +"', 'Lack of Materials')");
            st.execute(complainEnv);
        }

        if(complain.getNoiseComplaint()==true)
        {
            complainID+=1;
            String complainEnv=("insert into complaint(complaintID, transactionID, StudentRollNo, Complaint)" + "values ('"+ complainID +"', '"+ transactionID +"', '"+ student.getRollno() +"', 'Noise Disturbance')");
            st.execute(complainEnv);
        }


        complaintMessage.setText("Complaint Filed Successfully!");
    }



    //===========================
    //      TITLE HOME PAGE
    //===========================

    public void title_registerOnAction(ActionEvent a) throws IOException
    {
        Parent root = FXMLLoader.load(getClass().getResource("Registration_Portal.fxml"));
        Stage window= (Stage)title_register.getScene().getWindow();
        window.setScene(new Scene(root, 668,503));
    }

    public void title_loginOnAction(ActionEvent a) throws IOException
    {
        Parent root = FXMLLoader.load(getClass().getResource("Login_Portal.fxml"));
        Stage window= (Stage)title_login.getScene().getWindow();
        window.setScene(new Scene(root, 628,555));
    }


    //===========================
    //      VERIFY STUDENT
    //===========================





    //===========================
    //      STUDENT HOME PAGE
    //===========================

    @FXML
    public void logoutclose(MouseEvent event) {
        Stage stage = (Stage) LogoutButton.getScene().getWindow();
        stage.close();
    }
    @FXML
    public void logout(javafx.scene.input.MouseEvent mouseEvent) throws IOException {

        logoutclose(mouseEvent);
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Login_Portal.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();

        stage.setTitle("Login Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void fileComplaintLabelOnMouseClicked(javafx.scene.input.MouseEvent mouseEvent) throws IOException {
        Stage stage = (Stage) fileComplaintLabel.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Complaint.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 600, 400);
        MainUIController cpc=fxmlLoader.getController();

        stage.setTitle("Complaint Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void recommendCourseLabelOnMouseClicked(javafx.scene.input.MouseEvent mouseEvent) throws IOException
    {
        Stage stage = (Stage) recommendCourseLabel.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Recommendation_Page.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 600, 400);
        MainUIController cpc=fxmlLoader.getController();

        stage.setTitle("Complaint Portal");
        stage.setScene(scene);
        stage.show();
    }

    //================================
    //      RECOMMENDATION ~HOME~ PAGE
    //=================================

    @FXML
    public void courseListButtonOnAction(ActionEvent e) throws IOException, SQLException {
        Stage stage = (Stage) recListCourseButton.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("List_Course.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();
        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select * from proj.course;");
        ResultSet rs=st.executeQuery(query);

        cpc.courseCodeCol.setCellValueFactory(new PropertyValueFactory<Course, String>("courseCode"));
        cpc.CourseNameCol.setCellValueFactory(new PropertyValueFactory<Course, String>("courseName"));


        while(rs.next())
        {
            Course course = new Course();
            course.setCourseCode(rs.getString("CourseCode"));
            course.setCourseName(rs.getString("courseName"));

            cpc.course_table.getItems().addAll(course);
        }


        stage.setTitle("Course List Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void courseRecButton(ActionEvent e) throws IOException
    {
        Stage stage = (Stage) recCourseButton.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Recommend_Course.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();

        stage.setTitle("Recommendation Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void recHomeHPReturn(javafx.scene.input.MouseEvent mouseEvent) throws IOException
    {
        Stage stage = (Stage) recHomeHP.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Student_Home.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();
        cpc.StudentName.setText(student.getName());
        cpc.StudentBatch.setText(student.getBatch());
        cpc.StudentRoll.setText(student.getRollno());

        stage.setTitle("Recommendation Portal");
        stage.setScene(scene);
        stage.show();
    }

    //===============================
    //      RECOMMENDATION COURSE PAGE
    //================================

    @FXML
    public void recommendHPReturn(javafx.scene.input.MouseEvent mouseEvent) throws IOException
    {
        Stage stage = (Stage) recommendHP.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Student_Home.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();
        cpc.StudentName.setText(student.getName());
        cpc.StudentBatch.setText(student.getBatch());
        cpc.StudentRoll.setText(student.getRollno());

        stage.setTitle("Student Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void recommendationSubmitButtonOnAction(ActionEvent e) throws SQLException
    {
        String code=recommend_codeField.getText();
        String bookName=recommend_bookNameField.getText();
        String author=recommend_authorField.getText();
        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();
        String query=("select max(ID) from proj.recommendations");
        ResultSet rs=st.executeQuery(query);
        int recID=0;

        if(rs.next())
        {
            recID=rs.getInt(1);
            recID += 1;
        }

        query=("select * from course where CourseCode='"+ code +"'");
        rs=st.executeQuery(query);

        if(rs.next())
        {
            String insert=("insert into recommendations(ID, courseCode, bookName, authorName)" + "values ('"+ recID +"', '"+ code +"', '"+ bookName + "', '"+ author +"' )");
            st.execute(insert);
            recommendationMessage.setText("Recommendation Noted Successfully!");
        }
        else
        {
            recommendationMessage.setText("The course you specified does not exist");
        }





    }



    //===========================
    //      COURSE LIST PAGE
    //===========================

    @FXML
    public void courseListHPReturn(javafx.scene.input.MouseEvent mouseEvent) throws IOException
    {
        Stage stage = (Stage) courseListHP.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Student_Home.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();
        cpc.StudentName.setText(student.getName());
        cpc.StudentBatch.setText(student.getBatch());
        cpc.StudentRoll.setText(student.getRollno());

        stage.setTitle("Recommendation Portal");
        stage.setScene(scene);
        stage.show();
    }


    //===========================
    //      LIBRARIAN HOME PAGE
    //===========================

    @FXML
    void setFinePaymentLabelOnMouseClicked(javafx.scene.input.MouseEvent event) throws IOException
    {
        Stage stage = (Stage) finePaymentLabel.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Pay_Fine.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 623, 515);
        MainUIController cpc=fxmlLoader.getController();

        stage.setTitle("Fine Payment Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void bookRecordsLabelOnMouseClicked(javafx.scene.input.MouseEvent event) throws IOException
    {
        Stage stage = (Stage) bookRecordsLabel.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Manage_Books.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 600, 400);
        MainUIController cpc=fxmlLoader.getController();

        stage.setTitle("Book Management Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void studentRecordsLabelOnMouseClicked(javafx.scene.input.MouseEvent event) throws IOException
    {
        Stage stage = (Stage) manageStudentLabel.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Manage_Students.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 600, 400);
        MainUIController cpc=fxmlLoader.getController();

        stage.setTitle("Student Management Portal");
        stage.setScene(scene);
        stage.show();
    }

    //===========================
    //      FINE PAYMENT PAGE
    //===========================

    @FXML
    void setFineHPReturnOnMouseClicked(javafx.scene.input.MouseEvent event) throws IOException
    {
        Stage stage = (Stage) fineHPReturn.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Librarian_Home.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);

        MainUIController cpc=fxmlLoader.getController();
        cpc.LibrarianName.setText(librarian.getLibName());
        cpc.LibrarianID.setText(librarian.getLibID());

        stage.setTitle("Librarian Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void checkFineButtonOnAction(ActionEvent e) throws SQLException {
        String rollNum= fineRollNumberField.getText();

        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select * from proj.Student where rollNo='"+ rollNum +"';");
        ResultSet rs=st.executeQuery(query);

        if(rs.next())
        {
            int fineStatus= rs.getInt("fineStatus");
            String name= rs.getString("Name");
            String batch=rs.getString("Batch");
            String userName=rs.getString("username");

            student.setStudent(name, rollNum, batch, userName, fineStatus);

            query=("select * from proj.borrowed_books_logs where student_id='"+ rollNum +"';");
            rs=st.executeQuery(query);

            if(rs.next())
            {
                String date_returned= rs.getString("date_returned");

                if(date_returned==null)
                {
                    fineCalculationLabel.setText("Fine cannot be calculated until book is returned");
                }
                else
                {
                    if(fineStatus>0)
                    {
                        query=("select datediff(date_returned, date_borrowed) from proj.borrowed_books_logs where student_id='"+ rollNum +"' ;");
                        rs=st.executeQuery(query);
                        int money=0;
                        while(rs.next())
                        {
                            if(rs.getInt(1) > 14)
                            {
                                int days=rs.getInt(1)-14;
                                money=days*fine;
                                break;
                            }
                        }

                        fineCalculationLabel.setText(rollNum +", " + name + " has fine of Rs." + money);
                    }
                    else
                    {
                        fineCalculationLabel.setText(rollNum +", " + name + " does not have any dues");
                    }
                }
            }

        }
        else
        {
            fineCalculationLabel.setText("Roll Number Does not exist, please try again");
        }

        connectDB.close();
    }

    @FXML
    void paymentButtonOnAction(ActionEvent e) throws SQLException
    {
        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("UPDATE proj.student SET fineStatus = 0 WHERE RollNo = '"+ student.getRollno() +"' ;");
        st.execute(query);
        fineCalculationLabel.setText("Dues cleared!");
        connectDB.close();
    }

    //===========================
    //      MANAGE BOOKS PAGE
    //===========================

    @FXML
    void addBookButtonOnAction(ActionEvent e) throws IOException
    {
        Stage stage = (Stage) addBookButton.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Add_Books.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 593, 433);
        MainUIController cpc=fxmlLoader.getController();

        stage.setTitle("Book Management Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void deleteBookButtonOnAction(ActionEvent e) throws IOException
    {
        Stage stage = (Stage) deleteBookButton.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Delete_Books.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 600, 400);
        MainUIController cpc=fxmlLoader.getController();

        stage.setTitle("Book Management Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void updateBookButtonOnAction(ActionEvent e) throws IOException
    {
        Stage stage = (Stage) updateBookButton.getScene().getWindow();
        stage.close();
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Update_Books.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 600, 400);
        MainUIController cpc=fxmlLoader.getController();

        stage.setTitle("Book Management Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void ListBookButtonOnAction(ActionEvent e) throws IOException, SQLException {
        Stage stage = (Stage) listBookButton.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("List_Books.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 600, 400);
        MainUIController cpc=fxmlLoader.getController();

        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select * from proj.book;");
        ResultSet rs=st.executeQuery(query);

        cpc.book_isbnCol.setCellValueFactory(new PropertyValueFactory<Book, String>("ISBN"));
        cpc.book_nameCol.setCellValueFactory(new PropertyValueFactory<Book, String>("name"));
        cpc.book_categoryCol.setCellValueFactory(new PropertyValueFactory<Book,String>("category"));


        while(rs.next())
        {
            Book book= new Book();
            book.setISBN(rs.getString("isbn"));
            book.setName(rs.getString("name"));
            book.setCategory(rs.getString("category"));
            //book_list.add(book);
            //book_table.setItems(book_list)
            //
            System.out.println("Book ISBN: "+ book.getISBN());
            System.out.println("Book Name: "+ book.getName());
            System.out.println("Book Cat: "+ book.getCategory());
            cpc.book_table.getItems().addAll(book);
        }


        stage.setTitle("Book Management Portal");
        stage.setScene(scene);
        stage.show();




        //listingBooks(cpc);

    }


    @FXML
    public void manageBookHPReturn(javafx.scene.input.MouseEvent event) throws IOException
    {
        Stage stage = (Stage) manageBookHPLabel.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Librarian_Home.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();
        cpc.LibrarianName.setText(librarian.getLibName());
        cpc.LibrarianID.setText(librarian.getLibID());

        stage.setTitle("Book Management Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void viewRecsButtonOnAction(ActionEvent e)throws IOException, SQLException {
        Stage stage = (Stage) viewRecsButton.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("View_Recommendations.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();

        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select * from proj.recommendations;");
        ResultSet rs=st.executeQuery(query);

        cpc.recIDCol.setCellValueFactory(new PropertyValueFactory<Recommendation, String>("ID"));
        cpc.viewCourseCodeCol.setCellValueFactory(new PropertyValueFactory<Recommendation, String>("courseCode"));
        cpc.bookNameCol.setCellValueFactory(new PropertyValueFactory<Recommendation,String>("bookName"));
        cpc.authorCol.setCellValueFactory(new PropertyValueFactory<Recommendation,String>("author"));


        while(rs.next())
        {
            Recommendation rec= new Recommendation();
            rec.setAuthor(rs.getString("authorName"));
            rec.setBookName(rs.getString("bookName"));
            rec.setID(rs.getString("ID"));
            rec.setCourseCode(rs.getString("courseCode"));
            cpc.recommendation_table.getItems().addAll(rec);
        }


        stage.setTitle("Book Management Portal");
        stage.setScene(scene);
        stage.show();


    }

    //==================================
    //      VIEW BOOK RECOMMENDATION PAGE
    //==================================

    @FXML
    public void viewRecHPOnMouseClick(javafx.scene.input.MouseEvent event)throws IOException
    {
        Stage stage = (Stage) viewRecHP.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Librarian_Home.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();
        cpc.LibrarianName.setText(librarian.getLibName());
        cpc.LibrarianID.setText(librarian.getLibID());

        stage.setTitle("Librarian Portal");
        stage.setScene(scene);
        stage.show();
    }


    //===========================
    //      LIST BOOKS PAGE
    //===========================

    @FXML
    void setListBookHPReturn(javafx.scene.input.MouseEvent event) throws IOException
    {
        Stage stage = (Stage) listBookHPLabel.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Librarian_Home.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();
        cpc.LibrarianName.setText(librarian.getLibName());
        cpc.LibrarianID.setText(librarian.getLibID());

        stage.setTitle("Librarian Portal");
        stage.setScene(scene);
        stage.show();
    }

    //===========================
    //      ADD BOOKS PAGE
    //===========================

    @FXML
    void addBookHPReturn(javafx.scene.input.MouseEvent event) throws IOException
    {
        Stage stage = (Stage) addBookHPLabel.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Librarian_Home.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();
        cpc.LibrarianName.setText(librarian.getLibName());
        cpc.LibrarianID.setText(librarian.getLibID());

        stage.setTitle("Book Management Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void setAddBookInfoButtonOnAction(ActionEvent e) throws SQLException
    {
        String isbn=addBookIsbnField.getText();
        String name=addBookNameFIeld.getText();
        String category=addBookCategoryField.getText();

        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select * from proj.book where isbn='"+ isbn +"';");
        ResultSet rs=st.executeQuery(query);

        if(rs.next())
        {
            addBookMessage.setText("This Book with the Specified ISBN already exists.");
        }
        else
        {
            String insert=("insert into Book(isbn, name, category, borrowStatus)" + "values ('"+ isbn +"', '"+ name +"', '"+ category + "', 'available' )");
            st.execute(insert);
            addBookMessage.setText("Book details successfully added!");
        }

        connectDB.close();

    }


    //===========================
    //      DELETE BOOKS PAGE
    //===========================

    @FXML
    void deleteBookHPReturn(javafx.scene.input.MouseEvent event) throws IOException
    {
        Stage stage = (Stage) deleteBookHPLabel.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Librarian_Home.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();
        cpc.LibrarianName.setText(librarian.getLibName());
        cpc.LibrarianID.setText(librarian.getLibID());

        stage.setTitle("Librarian Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void deleteBookInfoButtonOnAction(ActionEvent e) throws SQLException
    {
        String isbn=deleteBookIsbnField.getText();

        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select * from proj.book where isbn='"+ isbn +"';");
        ResultSet rs=st.executeQuery(query);

        if(rs.next())
        {
            String delete=("delete from proj.book where isbn='"+ isbn +"';");
            st.execute(delete);
            deleteMessage.setText("Book details successfully deleted!");

        }
        else
        {
            deleteMessage.setText("The book you are trying to delete does not exist");
        }

        connectDB.close();

    }

    //===========================
    //      UPDATE BOOKS PAGE
    //===========================

    @FXML
    void updateBookHPReturn(javafx.scene.input.MouseEvent event) throws IOException
    {
        Stage stage = (Stage) updateBookHPLabel.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Librarian_Home.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();
        cpc.LibrarianName.setText(librarian.getLibName());
        cpc.LibrarianID.setText(librarian.getLibID());

        stage.setTitle("Librarian Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void updateBookInfoButtonOnAction(ActionEvent e) throws SQLException
    {
        String isbn=updateBookIsbnField.getText();
        String newCat= updateBookCategoryField.getText();

        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select * from proj.book where isbn='"+ isbn +"';");
        ResultSet rs=st.executeQuery(query);

        if(rs.next())
        {
            String update=("UPDATE proj.book SET category = '"+ newCat +"' WHERE isbn= '"+ isbn +"' ;");
            st.execute(update);
            updateMessage.setText("Book category successfully updated!");

        }
        else
        {
            updateMessage.setText("The book you are trying to update does not exist");
        }

        connectDB.close();
    }



    //===========================
    //      MANAGE STUDENTS PAGE
    //===========================

    @FXML
    void addStudentButtonOnAction(ActionEvent e) throws IOException
    {
        Stage stage = (Stage) addStudentButton.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Add_Student.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 677, 496);
        MainUIController cpc=fxmlLoader.getController();

        stage.setTitle("Student Management Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void deleteStudentButtonOnAction(ActionEvent e) throws IOException
    {
        Stage stage = (Stage) deleteStudentButton.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Delete_Student.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 600, 400);
        MainUIController cpc=fxmlLoader.getController();

        stage.setTitle("Student Management Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void updateStudentButtonOnAction(ActionEvent e) throws IOException
    {
        Stage stage = (Stage) updateStudentButton.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Update_Student.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 600, 400);
        MainUIController cpc=fxmlLoader.getController();

        stage.setTitle("Student Management Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void ListStudentButtonOnAction(ActionEvent e) throws IOException, SQLException {
        Stage stage = (Stage) listStudentButton.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("List_Student.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 600, 400);
        MainUIController cpc=fxmlLoader.getController();

        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select * from proj.student;");
        ResultSet rs=st.executeQuery(query);

        cpc.stu_rollNumCol.setCellValueFactory(new PropertyValueFactory<Student, String>("Rollno"));
        cpc.stu_nameCol.setCellValueFactory(new PropertyValueFactory<Student, String>("Name"));
        cpc.stu_batchCol.setCellValueFactory(new PropertyValueFactory<Student,String>("Batch"));
        cpc.stu_fineCol.setCellValueFactory(new PropertyValueFactory<Student,String>("Finestatus"));
        cpc.stu_usernameCol.setCellValueFactory(new PropertyValueFactory<Student,String>("Username"));


        while(rs.next())
        {
            Student student= new Student();
            String name=rs.getString("Name");
            String rollNum=rs.getString("Rollno");
            String batch=rs.getString("Batch");
            Boolean fineStatus=rs.getBoolean("fineStatus");
            String user=rs.getString("username");
            int fine=0;

            if(fineStatus){fine=1;}

            student.setStudent(name,rollNum,batch,user,fine);

            cpc.student_table.getItems().addAll(student);
        }


        stage.setTitle("Book Management Portal");
        stage.setScene(scene);
        stage.show();



    }

    @FXML
    void manageStudentHPReturn(javafx.scene.input.MouseEvent event) throws IOException
    {
        Stage stage = (Stage) manageStudentHP.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Librarian_Home.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();
        cpc.LibrarianName.setText(librarian.getLibName());
        cpc.LibrarianID.setText(librarian.getLibID());

        stage.setTitle("Librarian Portal");
        stage.setScene(scene);
        stage.show();
    }

    //===========================
    //      ADD STUDENTS PAGE
    //===========================
    @FXML
    void addsStudentHPReturn(javafx.scene.input.MouseEvent event) throws IOException
    {
        Stage stage = (Stage) addStudentHP.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Librarian_Home.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();
        cpc.LibrarianName.setText(librarian.getLibName());
        cpc.LibrarianID.setText(librarian.getLibID());

        stage.setTitle("Librarian Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void setAddStudentInfoButtonOnAction(ActionEvent e) throws SQLException
    {
        String rollNum=addStudentRollNumField.getText();
        String name=addStudentNameField.getText();
        String batch=addStudentBatchField.getText();
        String username=addStudentUsernameField.getText();
        String password=addStudentPasswordField.getText();

        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select * from proj.student where RollNo='"+ rollNum +"';");
        ResultSet rs=st.executeQuery(query);

        if(rs.next())
        {
            addStudentMessage.setText("This Student already exists.");
        }
        else
        {
            String insertUser=("insert into user(ID, Password, Admin)" + "values ('"+ username +"', '"+ password +"', 0 );");
            st.execute(insertUser);

            String insert=("insert into Student(Rollno, name, batch, fineStatus, username)" + "values ('"+ rollNum +"', '"+ name +"', '"+ batch + "', 0, '"+ username +"' );");
            st.execute(insert);

            addStudentMessage.setText("Student details successfully added!");
        }

        connectDB.close();

    }

    //===========================
    //      DELETE STUDENTS PAGE
    //===========================
    @FXML
    void deleteStudentHPReturn(javafx.scene.input.MouseEvent event) throws IOException
    {
        Stage stage = (Stage) deleteStudentHP.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Librarian_Home.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();
        cpc.LibrarianName.setText(librarian.getLibName());
        cpc.LibrarianID.setText(librarian.getLibID());

        stage.setTitle("Librarian Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void deleteStudentInfoButtonOnAction(ActionEvent e) throws SQLException
    {
        String rollNum=deleteStudentRollNumField.getText();


        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select * from proj.student where RollNo='"+ rollNum +"';");
        ResultSet rs=st.executeQuery(query);

        if(rs.next())
        {
            String username=rs.getString("username");

            String deleteSt=("delete from proj.student where RollNo='"+ rollNum +"';");
            st.execute(deleteSt);


            String deleteUs=("delete from proj.user where ID='"+ username +"';");
            st.execute(deleteUs);

            deleteStudentMessage.setText("This Student has been deleted");
        }
        else
        {
            deleteStudentMessage.setText("The student does not exist");
        }

        connectDB.close();

    }

    //===========================
    //      UPDATE STUDENTS PAGE
    //===========================

    @FXML
    void updateStudentHPReturn(javafx.scene.input.MouseEvent event) throws IOException
    {
        Stage stage = (Stage) updateStudentHP.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Librarian_Home.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();
        cpc.LibrarianName.setText(librarian.getLibName());
        cpc.LibrarianID.setText(librarian.getLibID());

        stage.setTitle("Librarian Portal");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void updatePasswordButtonOnAction(ActionEvent e) throws IOException, SQLException {
       String username=updateStudentUserField.getText();
       String password=updateStudentPassField.getText();

        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select * from proj.user where ID='"+ username +"' AND Admin=0;");
        ResultSet rs=st.executeQuery(query);

        if(rs.next())
        {
            String update=("UPDATE proj.user SET password = '"+ password +"' WHERE ID= '"+ username +"' AND Admin=0 ;");
            st.execute(update);
            updatePasswordMessage.setText("Password successfully updated!");

        }
        else
        {
            updatePasswordMessage.setText("The user does not exist");
        }


    }

    //===========================
    //      LIST BOOKS PAGE
    //===========================
    @FXML
    void studentListHPReturn(javafx.scene.input.MouseEvent event) throws IOException
    {
        Stage stage = (Stage) studentListHP.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Librarian_Home.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainUIController cpc=fxmlLoader.getController();
        cpc.LibrarianName.setText(librarian.getLibName());
        cpc.LibrarianID.setText(librarian.getLibID());

        stage.setTitle("Librarian Portal");
        stage.setScene(scene);
        stage.show();
    }

    //===========================
    //      REGISTER HOME PAGE
    //===========================


    public void registerButtonOnAction(ActionEvent e) throws SQLException {
        String username= regUserName.getText();
        String password= regPassword.getText();
        String name=regName.getText();
        String userClearance=clearancePassword.getText();

        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();
        String query=("select max(LibrarianID) from proj.librarian");
        ResultSet rs=st.executeQuery(query);
        int ID=0;

        if(rs.next())
        {
            ID=rs.getInt(1);
            ID += 1;
        }


        if (userClearance.equals(CLEARANCE))
        {
            boolean validation= validateRegisteringUser(username, password);

            if(validation==true)
            {
                registerUser(ID, username, password,name);
                registerMessage.setText("Account Created!");
            }
            else
            {
                registerMessage.setText("The user already exists, Please try again");
            }

        }
        else
        {
            registerMessage.setText("You do not have permission to create an account!");
        }
    }

    public boolean validateRegisteringUser(String user, String pass)
    {
        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();

        String registerAttempt="SELECT COUNT(1) FROM proj.USER WHERE ID='" + user + "';";

        try
        {
            Statement sqlStatement= connectDB.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            ResultSet resultExist = sqlStatement.executeQuery(registerAttempt);

            resultExist.first();

            if(resultExist.getInt(1)==1)
            {
                registerMessage.setText("Username already exists, please try again");
                return false;
            }
            else if(resultExist.getInt(1)==0)
            {
                return true;
            }

        }catch(Exception e)
        {
            e.printStackTrace();
        }

        return true;
    }

    public void registerUser(int ID, String username, String password, String name) throws SQLException {
        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();

        String insert = " insert into proj.user (ID, Password, Admin)"
                + " values (?, ?, ?)";
        PreparedStatement preparedStmt = connectDB.prepareStatement(insert);
        preparedStmt.setString (1, username);
        preparedStmt.setString (2, password);
        preparedStmt.setBoolean(3, true);

        // execute the preparedstatement
        preparedStmt.execute();

        Statement st= connectDB.createStatement();

        insert=("insert into librarian(LibrarianID, LibrarianName, LibrarianUserName)" + "values ('"+ ID +"', '"+name+"', '"+ username + "' )");
        st.execute(insert);

        registerMessage.setText("You have been successfully registered!");
    }

    //===========================
    //      LOGIN PORTAL
    //===========================


    public void loginButtonOnAction(ActionEvent a)
    {
        loginValidation(a);

    }

    @FXML
    public void loginValidation(ActionEvent a)
    {
        databaseConnection connect= new databaseConnection();
        Connection connectDB= connect.getConnection();
        String userName=nameTextField.getText();
        String password=passwordTextField.getText();

        String loginAttempt="SELECT COUNT(1) FROM proj.USER WHERE ID='" + userName + "' AND PASSWORD='" + password + "';";

        try
        {
            Statement sqlStatement= connectDB.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            ResultSet resultExist = sqlStatement.executeQuery(loginAttempt);

            resultExist.first();


            if(resultExist.getInt(1)==1)
            {
                String checkForAdmin="SELECT Admin FROM proj.USER WHERE ID='" + userName + "' AND PASSWORD='" + password + "';";
                Statement sqlStatement2= connectDB.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                        ResultSet.CONCUR_UPDATABLE);
                ResultSet resultAdmin = sqlStatement.executeQuery(checkForAdmin);

                resultAdmin.first();

                if(resultAdmin.getInt(1)==1)
                {
                    loginMessage.setText("Logged in as admin");
                    Statement st = null;
                    try {
                        connectDB= connect.getConnection();
                        st=connectDB.createStatement();
                        //Librarian librarian = new Librarian();
                        //current_librarian=librarian;
                        String query=("select * from Librarian where LibrarianUserName='"+userName+"'");
                        ResultSet rs=st.executeQuery(query);
                        if(rs.next())
                        {
                            String name=rs.getString("LibrarianName");
                            String id=rs.getString("LibrarianUserName");
                            librarian.setLibName(name);
                            librarian.setLibId(id);

                            FXMLLoader fxmlLoader = new FXMLLoader();
                            fxmlLoader.setLocation(getClass().getResource("Librarian_Home.fxml"));
                            Parent root = fxmlLoader.load();
                            Scene scene = new Scene(root);

                            MainUIController cpc=fxmlLoader.getController();
                            cpc.LibrarianName.setText(name);
                            cpc.LibrarianID.setText(id);

                            stage.setTitle("Librarian Portal");
                            stage.setScene(scene);
                            stage.show();
                        }
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
                else if(resultAdmin.getInt(1)==0)
                {
                    try {
                        loginMessage.setText("Logged in as student");
                        connectDB= connect.getConnection();
                        Statement st = connectDB.createStatement();
                        //Student student = new Student();
                        //current_student=student;
                        String query=("select * from Student where username='"+userName+"'");
                        ResultSet rs=st.executeQuery(query);
                        if(rs.next())
                        {
                            String name=rs.getString("Name");
                            String rollno=rs.getString("Rollno");
                            String batch=rs.getString("Batch");
                            int finestatus=rs.getInt("fineStatus");
                            student.setStudent(name, rollno, batch, userName, finestatus);

                            System.out.println(name);

                            FXMLLoader fxmlLoader = new FXMLLoader();
                            fxmlLoader.setLocation(getClass().getResource("Student_Home.fxml"));
                            Parent root = fxmlLoader.load();
                            Scene scene = new Scene(root, 484, 470);

                            MainUIController cpc=fxmlLoader.getController();
                            cpc.StudentName.setText(name);
                            cpc.StudentBatch.setText(batch);
                            cpc.StudentRoll.setText(rollno);


                            stage.setTitle("Student Portal");
                            stage.setScene(scene);
                            stage.show();
                        }


                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }

            }
            else if (resultExist.getInt(1)==0)
            {
                loginMessage.setText("Login Failed");
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }


    //////////////////////////////////////////

    @FXML
    void submitReview(ActionEvent event) throws SQLException, IOException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        Review reviewobj = new Review();
        String ratinggiven = rating.getText();
        String justifyratinggiven = justifyRating.getText();
        reviewobj.setRating(ratinggiven);
        reviewobj.setReviewjustification(justifyratinggiven);
        reviewobj.setStudentid(studentloggedin.getRollno());
        databaseConnection connect = new databaseConnection();
        Connection connectDB = connect.getConnection();
        connectDB = connect.getConnection();
        Statement st = connectDB.createStatement();
        ResultSet rs =st.executeQuery("select count(*) from review");
        if(rs.next())
        {
            int count = rs.getInt(1);
            count++;
            reviewobj.setId(count);
            st.executeUpdate("Insert into review Values('"+reviewobj.getId()+"','"+reviewobj.getStudentid()+"','"+reviewobj.getRating()+"','"+reviewobj.getReviewjustification()+"')");

        }
        fxmlLoader.setLocation(getClass().getResource("Review_Successful.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        stage.setTitle("Verify Student Card");
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    void NavigateToReviewPage(ActionEvent event) throws IOException {
        reviewBook = reviewbookList.getSelectionModel().getSelectedItem();
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Review_Page.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);

        MainUIController cpc = fxmlLoader.getController();
        cpc.reviewBookLabel.setText(reviewBook);
        System.out.println(reviewBookLabel);
        System.out.println(reviewBook);

        //stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Review Book");
        stage.setScene(scene);
        stage.show();

    }
    @FXML
    void NavigateToReview(MouseEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Review_Book.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);

        try {
            databaseConnection connect = new databaseConnection();
            Connection connectDB = connect.getConnection();
            connectDB = connect.getConnection();
            Statement st = connectDB.createStatement();
            String rollno = studentloggedin.getRollno();
            ResultSet rs = st.executeQuery("select * from borrowed_books_logs where student_id='"+ rollno +"'");

            MainUIController cpc = fxmlLoader.getController();
            while (rs.next()) {  // loop

                cpc.reviewbookList.getItems().addAll(rs.getString("bookname"));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        stage.setTitle("Review Book");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void BorrowBook(ActionEvent event) throws SQLException, IOException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        FXMLLoader fxmlLoader = new FXMLLoader();
        MainUIController cuntroller = fxmlLoader.getController();
        databaseConnection connect = new databaseConnection();
        Connection connectDB = connect.getConnection();
        String rollNo = VerifyRollNo.getText();
        connectDB = connect.getConnection();
        Statement st = connectDB.createStatement();
        String status="Available";
        String bookname =borrowList.getSelectionModel().getSelectedItem();
        ResultSet rs = st.executeQuery("Select count(*) AS resultCount from book where name='"+ bookname +"' AND borrowStatus='"+ status +"'");
        if(rs.next())
        {
            int count = rs.getInt("resultCount");

            if(count==0)
            {
                fxmlLoader.setLocation(getClass().getResource("Donation_Warning.fxml"));
                Parent root = fxmlLoader.load();
                Scene scene = new Scene(root);
                stage.setTitle("Verify Student Card");
                stage.setScene(scene);
                stage.show();

            }
            else
            {
                Statement st1 = connectDB.createStatement();
                ResultSet rs2 = st1.executeQuery("select count(*) AS countings from transaction");
                String Borrow = "Borrow";
                String borrowStatus = "Unavailable";
                if(rs2.next())
                {
                    int countTransaction = rs2.getInt("countings");
                    countTransaction++;
                    st1.executeUpdate("insert into transaction VALUES('" + countTransaction + "','" + Borrow +"','" + rollnoverify + "')");
                    currentTransaction.setTransactionID(countTransaction);
                    currentTransaction.setOperation(Borrow);
                    currentTransaction.setStudentID(rollnoverify);
                    st1.executeUpdate("UPDATE book SET borrowStatus=('" + borrowStatus + "') where name='"+ bookname +"';");
                    st1.executeUpdate("Insert into borrowed_books_logs(transactionID, bookname, student_id, date_borrowed) VALUES('"+ countTransaction+ "','" +bookname+ "','" +rollnoverify+"','" + formatter.format(date)+"')");
                }

                fxmlLoader.setLocation(getClass().getResource("Borrow_Success.fxml"));
                Parent root = fxmlLoader.load();
                Scene scene = new Scene(root);
                stage.setTitle("Verify Student Card");
                stage.setScene(scene);
                stage.show();
            }
        }

    }

    @FXML
    void NavigateToBorrow(MouseEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("StudentCardVerification_Borrow.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);

        stage.setTitle("Verify Student Card");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void printReceipt(ActionEvent event)
    {
        System.out.println("Transaction ID: "+ currentTransaction.getTransactionID());
        System.out.println("Operation: "+currentTransaction.getOperation());
        System.out.println("Student ID: "+currentTransaction.getStudentID());
    }

    @FXML
    void submitFeedback(ActionEvent event) throws SQLException {
        String choiceq1, choiceq2, choiceq3, choiceq4, choiceq5, choiceq6;
        choiceq1=q1.getSelectionModel().getSelectedItem();
        choiceq2=q2.getSelectionModel().getSelectedItem();
        choiceq3=q3.getSelectionModel().getSelectedItem();
        choiceq4=q4.getSelectionModel().getSelectedItem();
        choiceq5=q5.getSelectionModel().getSelectedItem();
        choiceq6=q6.getSelectionModel().getSelectedItem();

        FXMLLoader fxmlLoader = new FXMLLoader();
        databaseConnection connect = new databaseConnection();
        Connection connectDB = connect.getConnection();
        connectDB = connect.getConnection();
        Statement st = connectDB.createStatement();
        ResultSet rs2 = st.executeQuery("select count(*) as countings from transaction");
        if(rs2.next())
        {
            String Feedback = "Feedback";
            int countTransaction = rs2.getInt("countings");
            countTransaction++;
            currentTransaction.setTransactionID(countTransaction);
            currentTransaction.setOperation(Feedback);
            currentTransaction.setStudentID(studentloggedin.getRollno());
            st.executeUpdate("insert into transaction VALUES('" + countTransaction + "','" + Feedback +"','" + studentloggedin.getRollno() + "')");
            st.executeUpdate("insert into feedback VALUES('"+ countTransaction +"','" + studentloggedin.getRollno() +"','" + studentloggedin.getName() + "','" +courseforfeedback+ "','"+choiceq1+"','" +choiceq2+"','"+choiceq3+"','"+choiceq4+"','"+choiceq5+"','"+choiceq6+"','"+feedbackText.getText()+"' )");
        }

    }

    @FXML
    void DonateBook(ActionEvent event) throws SQLException, IOException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        MainUIController cuntroller = fxmlLoader.getController();
        databaseConnection connect = new databaseConnection();
        Connection connectDB = connect.getConnection();
        String rollNo = VerifyRollNo.getText();
        connectDB = connect.getConnection();
        Statement st = connectDB.createStatement();
        String isbn = ISBN.getText();
        String bookname = BookName.getText();
        String category = Category.getText();
        System.out.println(rollnoverify);
        ResultSet rs = st.executeQuery("Select count(*) AS resultCount from book where name='"+ bookname +"'");
        if(rs.next())
        {
            int count = rs.getInt("resultCount");

            if(count>2)
            {
                fxmlLoader.setLocation(getClass().getResource("Donation_Warning.fxml"));
                Parent root = fxmlLoader.load();
                Scene scene = new Scene(root);
                stage.setTitle("Verify Student Card");
                stage.setScene(scene);
                stage.show();

            }
            else
            {
                Statement st1 = connectDB.createStatement();
                ResultSet rs2 = st1.executeQuery("select count(*) AS countings from transaction");
                String Donation = "Donate";
                String BorrowStatus = "Available";
                if(rs2.next())
                {
                    int countTransaction = rs2.getInt("countings");
                    countTransaction++;
                    st1.executeUpdate("insert into transaction VALUES('" + countTransaction + "','" + Donation +"','" + rollnoverify + "')");
                    currentTransaction.setTransactionID(countTransaction);
                    currentTransaction.setOperation(Donation);
                    currentTransaction.setStudentID(rollnoverify);
                    st1.executeUpdate("insert into book VALUES('"+ isbn +"','" + bookname +"','" + category + "','" +BorrowStatus+ "')");
                    st1.executeUpdate("Insert into donated_books VALUES('"+ countTransaction+ "','" +rollnoverify+ "','" +isbn+"')");
                }

                fxmlLoader.setLocation(getClass().getResource("Donation_Success.fxml"));
                Parent root = fxmlLoader.load();
                Scene scene = new Scene(root);
                stage.setTitle("Verify Student Card");
                stage.setScene(scene);
                stage.show();
            }
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        List<String> strings = new ArrayList<>();
        List<String> strings1 = new ArrayList<>();
        q1.getItems().addAll(goodchoices);
        q2.getItems().addAll(goodchoices);
        q3.getItems().addAll(agreechoices);
        q4.getItems().addAll(agreechoices);
        q5.getItems().addAll(agreechoices);
        q6.getItems().addAll(agreechoices);
        databaseConnection connect = new databaseConnection();
        Connection connectDB = connect.getConnection();
        String rollNo = VerifyRollNo.getText();
        connectDB = connect.getConnection();
        try {
            Statement st = connectDB.createStatement();
            ResultSet rs = st.executeQuery("select * from course");

            while (rs.next()) {  // loop

                // Now add the comboBox addAll statement
                courseChoice.getItems().addAll(rs.getString("courseName"));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        try {
            Statement st = connectDB.createStatement();
            ResultSet rs = st.executeQuery("select name from book where borrowStatus='Available'");

            while (rs.next()) {  // loop

                borrowList.getItems().addAll(rs.getString("name"));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }



    }

    @FXML
    void NavigateToFeedbackForm(ActionEvent event) throws IOException {
        courseforfeedback=courseChoice.getSelectionModel().getSelectedItem();
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Feedback_Form.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        String name = courseChoice.getValue();
        MainUIController cuntroller = fxmlLoader.getController();
        cuntroller.courseName.setText(name);


        MainUIController cpc = fxmlLoader.getController();
        cpc.courseName.setText(courseforfeedback);
        System.out.println(reviewBookLabel);
        System.out.println(reviewBook);

        System.out.println(courseName.getText());
        stage.setTitle("Verify Student Card");
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    void NavigateToCourseFeedback(MouseEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Course_Feedback.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);


        stage.setTitle("Verify Student Card");
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    public void NavigateToDonation(javafx.scene.input.MouseEvent event) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("StudentCardVerification.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);

        stage.setTitle("Verify Student Card");
        stage.setScene(scene);
        stage.show();
    }


    @FXML
    void verifyrollno(ActionEvent event) throws IOException, SQLException {

        databaseConnection connect = new databaseConnection();
        Connection connectDB = connect.getConnection();
        String rollNo = VerifyRollNo.getText();
        rollnoverify=VerifyRollNo.getText();
        connectDB = connect.getConnection();
        Statement st = connectDB.createStatement();
        Librarian librarian = new Librarian();
        String query = ("select * from studentcard where RollNo= '" + rollnoverify + "'");
        ResultSet rs = st.executeQuery(query);
        if (rs.next()) {
            if (rs.getString("RollNo") != "") {

                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("Donate_Book.fxml"));
                Parent root = fxmlLoader.load();
                Scene scene = new Scene(root);
                MainUIController cpc = new MainUIController();
                cpc.VerifyFailed.setText("Verification Failed!");
                stage.setTitle("Donate Book");
                stage.setScene(scene);
                stage.show();
            }

        }
        else {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("Verification_Failed.fxml"));
            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            MainUIController cpc = new MainUIController();
            cpc.VerifyFailed.setVisible(true);
            stage.setScene(scene);
            stage.show();
        }


    }

    @FXML
    void verifyrollno_borrow(ActionEvent event) throws IOException, SQLException {

        databaseConnection connect = new databaseConnection();
        Connection connectDB = connect.getConnection();
        String rollNo = VerifyRollNo.getText();
        rollnoverify=VerifyRollNo.getText();
        connectDB = connect.getConnection();
        Statement st = connectDB.createStatement();
        Librarian librarian = new Librarian();
        String query = ("select * from studentcard where RollNo= '" + rollnoverify + "'");
        ResultSet rs = st.executeQuery(query);
        if (rs.next()) {
            if (rs.getString("RollNo") != "") {

                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("Borrow_Book.fxml"));
                Parent root = fxmlLoader.load();
                Scene scene = new Scene(root);
                MainUIController cpc = new MainUIController();
                cpc.VerifyFailed.setText("Verification Failed!");
                stage.setTitle("Borrow Book");
                stage.setScene(scene);
                stage.show();
            }

        }
        else {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("Verification_Failed.fxml"));
            Parent root = fxmlLoader.load();
            Scene scene = new Scene(root);
            MainUIController cpc = new MainUIController();
            cpc.VerifyFailed.setVisible(true);
            stage.setScene(scene);
            stage.show();
        }


    }

}