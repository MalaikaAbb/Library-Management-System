package sda_project;

public class Complaint {
    private Boolean noiseComplaint;
    private Boolean materialComplaint;
    private Boolean envComplaint;

    public void setNoiseComplaint(Boolean value) { noiseComplaint=value; }

    public void setMaterialComplaint(Boolean value) { materialComplaint=value; }

    public void setEnvComplaint(Boolean value) { envComplaint=value; }

    public Boolean getNoiseComplaint() { return noiseComplaint; }

    public Boolean getMaterialComplaint() { return materialComplaint; }

    public Boolean getEnvComplaint() { return  envComplaint; }
}
