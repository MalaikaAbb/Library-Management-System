package sda_project;

public class Recommendation {

    private String ID;
    private String courseCode;
    private String bookName;
    private String author;

    public void setID(String ID){this.ID=ID;}
    public void setCourseCode(String code){courseCode=code;}
    public void setBookName(String name){bookName=name;}
    public void setAuthor(String author){this.author=author;}

    public String getID(){return ID;}
    public String getCourseCode(){return courseCode;}
    public String getBookName(){return bookName;}
    public String getAuthor(){return author;}
}
