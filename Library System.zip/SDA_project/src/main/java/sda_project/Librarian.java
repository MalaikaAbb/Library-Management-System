package sda_project;

import com.mysql.cj.conf.StringProperty;
import javafx.beans.property.SimpleStringProperty;

public class Librarian {
    private String Librarian_Name;
    private String Librarian_ID;

    public Librarian()
    {
        this.Librarian_ID = "0";
        this.Librarian_Name = "0";
    }

    public void setLibName(String newname)
    {
        Librarian_Name=newname;
    }

    public void setLibId(String newid)
    {
        Librarian_Name=newid;
    }

    public String getLibName()
    {
        return Librarian_Name;
    }

    public String getLibID()
    {
        return Librarian_ID;
    }


}
