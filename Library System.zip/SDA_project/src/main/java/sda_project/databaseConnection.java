package sda_project;

import java.sql.Connection;
import java.sql.DriverManager;

public class databaseConnection {

    public Connection dbLink;

    public Connection getConnection()
    {
       String dbName="proj";
       String dbUser="root";
       String dbPassword="qamarun92!";
       String url="jdbc:mysql://localhost/" + dbName;

       try
       {
           Class.forName("com.mysql.cj.jdbc.Driver");
           dbLink = DriverManager.getConnection(url, dbUser, dbPassword);
       }

       catch (Exception e)
       {
            e.printStackTrace();
       }

       return dbLink;

    }
}
