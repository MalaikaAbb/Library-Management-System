package sda_project;

public class Student {
    private String Name;
    private String Rollno;
    private String Batch;
    private String Username;
    private int Finestatus;
    public Student()
    {
        Name="";
        Rollno="";
        Batch="";
        Username="";
        Finestatus=0;
    }

    public void setStudent(String Name, String Rollno, String Batch, String Username, int finestatus)
    {
        this.Name=Name;
        this.Rollno=Rollno;
        this.Batch=Batch;
        this.Username=Username;
        this.Finestatus=finestatus;
    }

    public String getName() {
        return Name;
    }

    public String getBatch() {
        return Batch;
    }

    public String getRollno() {
        return Rollno;
    }

    public String getUsername() {
        return Username;
    }

    public int getFinestatus() {
        return Finestatus;
    }
}
