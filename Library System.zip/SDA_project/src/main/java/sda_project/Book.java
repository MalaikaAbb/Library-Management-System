package sda_project;

public class Book {

    private String ISBN;
    private String name;
    private String category;

    public void setISBN(String isbn){ISBN=isbn;}
    public void setName(String n){name=n;}
    public void setCategory(String cat){category=cat;}

    public String getISBN(){ return ISBN; }
    public String getName(){ return name; }
    public String getCategory(){return category; }

}
